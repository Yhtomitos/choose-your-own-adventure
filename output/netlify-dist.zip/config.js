// Generated at build time for Netlify static deployment.
window.CYOA_API_BASE = '';
